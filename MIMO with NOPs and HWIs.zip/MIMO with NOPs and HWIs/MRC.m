function [Rs1,Rs2]=MRC(zeta,tau,N,K,M,K11,K22,rho,delta,beta_ii,beta_li,CSI_flag)%M
nbrBSs=7;%��վ��Ŀ
Rs1=zeros(1,length(M));
Rs2=zeros(1,length(M));
p=10;
sbrli=0;%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end
%
a=(1-rho)*((rho+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p+1);
b=(1-rho)*sqrt(p);
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
eta=tau*lambda/(a/b^2*lambda+K);%imperfect CSI
%
if CSI_flag%perfect CSI
    tau=0;
    eta=1;
end
for i=1:length(M)
Hl=GHl(M(i),K);
Hh=sqrt(eta)*sqrt(1/2)*(randn(M(i),K)+1i*randn(M(i),K));
%analysis
Rsum1=0;

for t=1:K
sum1=0;
u=1:K;
u(find(u==t))=[];
for n=u
    sum1=sum1+norm(dot(Hl(:,t),Hl(:,n)))^2;
end
%
gamma1=(1-rho)*((M(i)+1)*p*eta^2+2*(M(i)+1)*K11*p*eta+M(i)*K11^2*p)/(((M(i)*delta^2-1)*(1-rho)+rho*(1+delta^2))*p*eta^2+(2*((M(i)+rho)*delta^2+2*rho-1)*K11*p+K11+1+(1+delta^2)*(K11+1)*p*sum(sbrli+1))*eta+M(i)*(1-rho)*delta^2*K11^2*p+(1+delta^2)*(1+rho*K11)*K11*K*p+K11*(K11+1)+(1+delta^2)*(K11+1)*K11*p*sum(sbrli)+1/M(i)*(1-rho)*(1+delta^2)*K11^2*p*sum1);
Rsum1=Rsum1+zeta*(1-tau/N)*log2(1+gamma1);
end
Rs1(i)=Rsum1;
%simulation
C=(1-rho)^2*delta^2*(K11*p/(K11+1)*(Hl*Hl')+p/(K11+1)*(Hh*Hh')+sqrt(K11)*p/(K11+1)*Hl*Hh'+sqrt(K11)*p/(K11+1)*Hh*Hl')+(1-rho)*rho*(1+delta^2)*diag(diag(p/(K11+1)*(Hh*Hh')+K11*p/(K11+1)*(Hl*Hl')+sqrt(K11)*p/(K11+1)*Hl*Hh'+sqrt(K11)*p/(K11+1)*Hh*Hl'))+(1-rho)*(rho+delta^2)*(1-eta)*K*p/(K11+1)*eye(M(i))+(1-rho)*(1+delta^2)*p*sum(sbrli)*eye(M(i))+(1-rho)*eye(M(i));
Rsum2=0;
for m=1:K
sum2=0;
v= 1:K;
v(find(v==m))=[];
for j=v
    sum2=sum2+norm(dot(sqrt(K11)*Hl(:,m)+Hh(:,m),sqrt(K11)*Hl(:,j)+Hh(:,j)))^2;
end
gamma2=p*norm(sqrt(K11)*Hl(:,m)+Hh(:,m))^4/(p*sum2+(1-eta)*K*p*norm(sqrt(K11)*Hl(:,m)+Hh(:,m))^2+(K11+1)/(1-rho)^2*(sqrt(K11)*Hl(:,m)+Hh(:,m))'*C*(sqrt(K11)*Hl(:,m)+Hh(:,m)));
Rsum2=Rsum2+zeta*(1-tau/N)*log2(1+gamma2);
end
Rs2(i)=Rsum2;
end
