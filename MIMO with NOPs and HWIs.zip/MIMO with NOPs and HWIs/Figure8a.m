clear all
clc
Q=16;%��������
K=120;M=1000;%M=500 or 1000
b_ad=1:Q;
[beta_ii,beta_il,beta_li]=pathlossgenerate(K);

for M=[300 600 1000]
[EE1,EEzf,Rs1,Rszf1]=EE_MRC_ZF(Q,M,beta_ii,beta_il,beta_li);%M=1000
plot(Rs1,EE1*10^-6,'s--r',Rszf1,EEzf*10^-6,'x--b','LineWidth',1)%Mbit/Joule
hold on
end
legend('MRC','ZF')
xlabel('Uplink Spectral Efficiency (bit/s/Hz)')
ylabel('Uplink Energy Efficiency (Mbit/Joule)')

