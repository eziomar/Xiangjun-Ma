function [Rs]=MRC_CDF(zeta,tau,N,K,M,K11,K22,rho,delta,beta_ii,beta_li)%M
nbrBSs=7;%��վ��Ŀ
Rs=zeros(K,1);%K���û��ֱ������
p=10;
sbrli=0;%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end
%
a=(1-rho)*((rho+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p+1);
b=(1-rho)*sqrt(p);
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
eta=tau*lambda/(a/b^2*lambda+K);%imperfect CSI
%
Hlcell=load('Hl.mat','Hl');
Hl=Hlcell.Hl;
Hh=sqrt(eta)*sqrt(1/2)*(randn(M,K)+1i*randn(M,K));
%simulation
C=(1-rho)^2*delta^2*(K11*p/(K11+1)*(Hl*Hl')+p/(K11+1)*(Hh*Hh')+sqrt(K11)*p/(K11+1)*Hl*Hh'+sqrt(K11)*p/(K11+1)*Hh*Hl')+(1-rho)*rho*(1+delta^2)*diag(diag(p/(K11+1)*(Hh*Hh')+K11*p/(K11+1)*(Hl*Hl')+sqrt(K11)*p/(K11+1)*Hl*Hh'+sqrt(K11)*p/(K11+1)*Hh*Hl'))+(1-rho)*(rho+delta^2)*(1-eta)*K*p/(K11+1)*eye(M)+(1-rho)*(1+delta^2)*p*sum(sbrli)*eye(M)+(1-rho)*eye(M);
for m=1:K
sum2=0;
v= 1:K;
v(find(v==m))=[];
for j=v
    sum2=sum2+norm(dot(sqrt(K11)*Hl(:,m)+Hh(:,m),sqrt(K11)*Hl(:,j)+Hh(:,j)))^2;
end
gamma2=p*norm(sqrt(K11)*Hl(:,m)+Hh(:,m))^4/(p*sum2+(1-eta)*K*p*norm(sqrt(K11)*Hl(:,m)+Hh(:,m))^2+(K11+1)/(1-rho)^2*(sqrt(K11)*Hl(:,m)+Hh(:,m))'*C*(sqrt(K11)*Hl(:,m)+Hh(:,m)));
Rs(m)=zeta*(1-tau/N)*log2(1+gamma2);
end


