clear all%��Ҫ���GHl_for_CDFһ��
clc
mont=350;
zeta=0.5;tau=100;N=1800;K=120;M=600;K22=10^0.3;K11=10^0.3;
rho=[0,0.03454];delta=[0,0.5];
Rs1_tot=zeros(K,mont);
Rs2_tot=zeros(K,mont);
Rs3_tot=zeros(K,mont);
Rs4_tot=zeros(K,mont);
%
Rszf1_tot=zeros(K,mont);
Rszf2_tot=zeros(K,mont);
Rszf3_tot=zeros(K,mont);
Rszf4_tot=zeros(K,mont);
[beta_ii,beta_il,beta_li]=pathlossgenerate(K);
for n=1:mont
Rs1=MRC_CDF(zeta,tau,N,K,M,K11,K22,rho(1),delta(1),beta_ii,beta_li);
Rs2=MRC_CDF(zeta,tau,N,K,M,K11,K22,rho(1),delta(2),beta_ii,beta_li);
Rs3=MRC_CDF(zeta,tau,N,K,M,K11,K22,rho(2),delta(1),beta_ii,beta_li);
%Rs4=MRC_CDF(zeta,tau,N,K,M,K11,K22,rho(2),delta(2),beta_ii,beta_li);
%
Rszf1=ZF_CDF(zeta,tau,N,K,M,K11,K22,rho(1),delta(1),beta_ii,beta_li);
Rszf2=ZF_CDF(zeta,tau,N,K,M,K11,K22,rho(1),delta(2),beta_ii,beta_li);
Rszf3=ZF_CDF(zeta,tau,N,K,M,K11,K22,rho(2),delta(1),beta_ii,beta_li);
%Rszf4=ZF_CDF(zeta,tau,N,K,M,K11,K22,rho(2),delta(2),beta_ii,beta_li);

Rs1_tot(:,n)=real(Rs1);
Rs2_tot(:,n)=real(Rs2);
Rs3_tot(:,n)=real(Rs3);
%Rs4_tot(:,n)=real(Rs4);
%
Rszf1_tot(:,n)=real(Rszf1);
Rszf2_tot(:,n)=real(Rszf2);
Rszf3_tot(:,n)=real(Rszf3);
%Rszf4_tot(:,n)=real(Rszf4);
end
hold on;box on;
p1=plot([0;sort(Rs1_tot(:));1.3],[0,linspace(0,1,K*mont),1],'--k','LineWidth',2);
p2=plot([0;sort(Rs2_tot(:));1.3],[0,linspace(0,1,K*mont),1],'--b','LineWidth',2);
p3=plot([0;sort(Rs3_tot(:));1.3],[0,linspace(0,1,K*mont),1],'--r','LineWidth',2);
%p4=plot([0;sort(Rs4_tot(:));1],[0,linspace(0,1,K*mont),1],'--g','LineWidth',2);
%
p5=plot([0;sort(Rszf1_tot(:));1.3],[0,linspace(0,1,K*mont),1],':k','LineWidth',2);
p6=plot([0;sort(Rszf2_tot(:));1.3],[0,linspace(0,1,K*mont),1],':b','LineWidth',2);
p7=plot([0;sort(Rszf3_tot(:));1.3],[0,linspace(0,1,K*mont),1],':r','LineWidth',2);
%p8=plot([0;sort(Rszf4_tot(:));1],[0,linspace(0,1,K*mont),1],':g','LineWidth',2);
xlabel('Spectral Efficiency per UE');
ylabel('Cumulative Distribution Function(CDF)');
legend([p1,p2,p3,p5,p6,p7],{'MRC (\rho_{ad}=0,\delta_{tx}=0)','MRC (\rho_{ad}=0,\delta_{tx}=0.5)','MRC (\rho_{ad}=0.03454,\delta_{tx}=0)','ZF (\rho_{ad}=0,\delta_{tx}=0)','ZF (\rho_{ad}=0,\delta_{tx}=0.5)','ZF (\rho_{ad}=0.03454,\delta_{tx}=0)'})
xlim([0 1.2])
