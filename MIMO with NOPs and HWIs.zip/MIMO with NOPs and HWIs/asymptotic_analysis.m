clear all
clc
p0=10;
zeta=0.5;tau=100;N=1800;K=120;
alpha=[0.5,1];K11=[0,10^0.9];
M_mrc=[10^3,0.3*10^4,10^4,0.3*10^5,10^5,0.3*10^6,10^6];%or M_mrt
M_zf=[10^3,0.3*10^4,10^4,0.3*10^5,10^5,0.3*10^6,10^6];
rho=0.1175;delta=0.1;K22=10^0.3;
[beta_ii,beta_il,beta_li]=pathlossgenerate(K);
%1:perfect;0:imperfect
%MRC
    %imperfect
    [R1a,R2a]=MRCa(zeta,tau,N,K,M_mrc,K11(1),K22,rho,delta,beta_ii,beta_li,0,alpha(1));
    [R1b,R2b]=MRCa(zeta,tau,N,K,M_mrc,K11(2),K22,rho,delta,beta_ii,beta_li,0,alpha(2));
    %perfect
    [Rp1a,Rp2a]=MRCa(zeta,tau,N,K,M_mrc,K11(1),K22,rho,delta,beta_ii,beta_li,1,alpha(2));
    [Rp1b,Rp2b]=MRCa(zeta,tau,N,K,M_mrc,K11(2),K22,rho,delta,beta_ii,beta_li,1,alpha(2));
%ZF  
    %imperfect
    [Rzf1a,Rzf2a]=ZFa(zeta,tau,N,K,M_zf,K11(1),K22,rho,delta,beta_ii,beta_li,0,alpha(1));
    [Rzf1b,Rzf2b]=ZFa(zeta,tau,N,K,M_zf,K11(2),K22,rho,delta,beta_ii,beta_li,0,alpha(2));
    %perfect
    [Rzfp1a,Rzfp2a]=ZFa(zeta,tau,N,K,M_zf,K11(1),K22,rho,delta,beta_ii,beta_li,1,alpha(2));
    [Rzfp1b,Rzfp2b]=ZFa(zeta,tau,N,K,M_zf,K11(2),K22,rho,delta,beta_ii,beta_li,1,alpha(2));
%�������ʷ���
%MRC
    %imperfect
    p1=semilogx(M_mrc,R1a,'o--g','LineWidth',1);
    hold on
    p2=semilogx(M_mrc,R1b,'+--b','LineWidth',1);
    hold on
    %perfect
    p3=semilogx(M_mrc,Rp1a,'o--g','LineWidth',1);
    hold on
    p4=semilogx(M_mrc,Rp1b,'+--b','LineWidth',1);
    hold on
%ZF 
    %imperfect
    p5=semilogx(M_zf,Rzf1a,'x--k','LineWidth',1);%ZF
    hold on
    p6=semilogx(M_zf,Rzf1b,'d--r','LineWidth',1);
    hold on
    %perfect
    p7=semilogx(M_zf,Rzfp1a,'x--k','LineWidth',1);
    hold on
    p8=semilogx(M_zf,Rzfp1b,'d--r','LineWidth',1);
    hold on
%������������
R_mrc_imp_nLOS=zeta*(1-tau/N)*log2(1+(1-rho)^2*tau*p0^2/(delta^2*(1-rho)^2*tau*p0^2+1));
R_mrc_imp_LOS=zeta*(1-tau/N)*log2(1+(1-rho)*K11(2)*p0/(delta^2*(1-rho)*K11(2)*p0+K11(2)+1));
R_mrc_p1=zeta*log2(1+(1-rho)*p0/(delta^2*(1-rho+2*rho*K11(1)/(K11(1)+1)^2)*p0+1));
R_mrc_p2=zeta*log2(1+(1-rho)*p0/(delta^2*(1-rho+2*rho*K11(2)/(K11(2)+1)^2)*p0+1));
%
R_zf_imp_nLOS=R_mrc_imp_nLOS;
R_zf_imp_LOS=R_mrc_imp_LOS;
R_zf_p=R_mrc_p1;

p9=semilogx(M_mrc,K*R_mrc_imp_nLOS*ones(size(M_mrc)),'r:','LineWidth',1);
hold on
p10=semilogx(M_mrc,K*R_mrc_imp_LOS*ones(size(M_mrc)),'k:','LineWidth',1);
hold on
%����������λ�ýӽ�
p11=semilogx(M_mrc,K*R_mrc_p1*ones(size(M_mrc)),'b:','LineWidth',1);
hold on
p12=semilogx(M_mrc,K*R_mrc_p2*ones(size(M_mrc)),'m:','LineWidth',1);
%ͼ��
legend([p1 p2 p5 p6 p9 p10 p11 p12],{'MRC (K_{ll}=-\inftydB)','MRC (K_{ll}=9dB)','ZF (K_{ll}=-\inftydB)','ZF(K_{ll}=9dB)','Asymptotic limit a','Asymptotic limit b','Asymptotic limit c','Asymptotic limit d'})
xlim([M_mrc(1) M_mrc(end)])
xlabel('Number of BS Antennas (\it{M})')
ylabel('Uplink Sum Rate \it{R_{u,l}^{mrc/zf}} (\it{R_{u,l}^{P,mrc/zf}})')

