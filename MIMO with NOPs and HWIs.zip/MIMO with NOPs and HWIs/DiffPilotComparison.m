clear all
clc
zeta=0.5;N=1800;
tau1=[200,300];K1=300;%tau(2)==K
tau2=[1000,1200];K2=1200;
M_mrc=[10 30 60 120 280 500 1024];%or M_mrt
M_zf=[125 200 280 500 750 1024];
rho=0.1175;delta=0.1;K22=10^0.3;
for K11=[0]%-\inftydB,3dB,6dB,9dB    
    [Rs1n,Rs1]=MRC_PilotComparison(zeta,tau1,N,K1,M_mrc,K11,rho,delta);
    [Rs2n,Rs2]=MRC_PilotComparison(zeta,tau2,N,K2,M_mrc,K11,rho,delta);
    p1=semilogx(M_mrc,Rs1n,'*--r','LineWidth',1);%MRC
    hold on
    p2=semilogx(M_mrc,Rs1,'+--b','LineWidth',1);
    hold on
    p3=semilogx(M_mrc,Rs2n,'*--g','LineWidth',1);%MRC
    hold on
    p4=semilogx(M_mrc,Rs2,'+--k','LineWidth',1);
end
legend([p1 p2 p3 p4],{'Non-OPs (\tau=200)','OPs (\tau=300)','Non-OPs (\tau=1000)','OPs (\tau=1200)'})
xlim([M_mrc(1) M_mrc(end)])
xlabel('Number of BS Antennas (\it{M})')
ylabel('Uplink Sum Rate R_{u,l}^{mrc}')
text(20,100,'K=300')
text(20,120,'K=1200')







