function [EE1,EEzf,Rs1,Rszf1]=EE_MRC_ZF(Q,M,beta_ii,beta_il,beta_li)
p=10;L_BS=12.8*10^9;
zeta=0.5;tau=100;N=1800;K=120;
delta=0.1;K22=10^0.3;K11=10^0.3;
B=20*10^6;%transmission bandwidth
P_LO=22.5*10^-3;P_MIX=0.3*10^-3;P_LF=14*10^-3;P_H=3*10^-3;P_LNA=5.4*10^-3;
f_s=2*B;
%%%%%%%%%%%%
b_ad=1:Q;b_da=b_ad;
rho_ad=pi*sqrt(3)/2*2.^(-2*b_ad);
rho_ad(1:5)=[0.3634 0.1175 0.03454 0.009497 0.002499];
rho_da=rho_ad;
%%%%%%%%%%%%%
nbrBSs=7;%��վ��Ŀ
Rs1=zeros(1,length(rho_ad));
Rs2=zeros(1,length(rho_ad));
Rszf1=zeros(1,length(rho_ad));
P_total=zeros(1,length(rho_ad));
sbrli=0;%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end
%
Hl=GHl(M,K);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%MRC
for i=1:length(rho_ad)
%channel estimation
a=(1-rho_ad(i))*((rho_ad(i)+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p+1);
b=(1-rho_ad(i))*sqrt(p);
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
eta=tau*lambda/(a/b^2*lambda+K);%imperfect CSI
%analysis
Rsum1=0;
for t=1:K
sum1=0;
u=1:K;
u(find(u==t))=[];
for n=u
    sum1=sum1+norm(dot(Hl(:,t),Hl(:,n)))^2;
end
%
gamma1=(1-rho_ad(i))*((M+1)*p*eta^2+2*(M+1)*K11*p*eta+M*K11^2*p)/(((M*delta^2-1)*(1-rho_ad(i))+rho_ad(i)*(1+delta^2))*p*eta^2+(2*((M+rho_ad(i))*delta^2+2*rho_ad(i)-1)*K11*p+K11+1+(1+delta^2)*(K11+1)*p*sum(sbrli+1))*eta+M*(1-rho_ad(i))*delta^2*K11^2*p+(1+delta^2)*(1+rho_ad(i)*K11)*K11*K*p+K11*(K11+1)+(1+delta^2)*(K11+1)*K11*p*sum(sbrli)+1/M*(1-rho_ad(i))*(1+delta^2)*K11^2*p*sum1);
Rsum1=Rsum1+zeta*(1-tau/N)*log2(1+gamma1);
end
Rs1(i)=Rsum1;
%
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ZF
Ol=sqrt(K11/(K11+1))*eye(K);Oh=sqrt(1/(K11+1))*eye(K);
for i=1:length(rho_ad)
%channel estimation
a=(1-rho_ad(i))*((rho_ad(i)+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p+1);
b=(1-rho_ad(i))*sqrt(p);
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
eta=tau*lambda/(a/b^2*lambda+K);%imperfect CSI
R=eta*Oh^2+1/M*Ol*(Hl'*Hl)*Ol;
Rf=R^-1;
%analysis
Rsumzf1=0;
for t=1:K
gammazf1=(1-rho_ad(i))*(K11+1)*p/((1-rho_ad(i))*delta^2*(K11+1)*p+((1+delta^2)*(1-eta)*K*p+rho_ad(i)*(1+delta^2)*(eta+K11)*K*p+K11+1+(1+delta^2)*(K11+1)*p*sum(sbrli))*Rf(t,t)/(M-K));
Rsumzf1=Rsumzf1+zeta*(1-tau/N)*log2(1+gammazf1);
end
Rszf1(i)=Rsumzf1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P_ADC=1432.1*10^-15*2.^b_ad*f_s;
P_LP1=B*(N-tau)/N*2*M*K/L_BS;
P_LPCmrc=B/N*3*M*K/L_BS;
P_LPCzf=B/N*(K^3/3+3*M*K^2+M*K)/L_BS;
P_CE=B/N*2*tau*M*K/L_BS;
P_total_mrc=P_LO+M*(2*P_MIX+2*P_LF+P_H+P_LNA+2*P_ADC)+P_LP1+P_LPCmrc+P_CE;
P_total_zf=P_LO+M*(2*P_MIX+2*P_LF+P_H+P_LNA+2*P_ADC)+P_LP1+P_LPCzf+P_CE;
%%%%%%%%%%%%%%%%%%
EE1=Rs1*B./P_total_mrc;
EEzf=Rszf1*B./P_total_zf;

