function [Rszf1,Rszf2]=ZF(zeta,tau,N,K,M,K11,K22,rho,delta,beta_ii,beta_li,CSI_flag)%M
Ol=sqrt(K11/(K11+1))*eye(K);Oh=sqrt(1/(K11+1))*eye(K);
nbrBSs=7;%��վ��Ŀ
Rszf1=zeros(1,length(M));
Rszf2=zeros(1,length(M));
p=10;
sbrli=0;%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end
%
a=(1-rho)*((rho+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p+1);
b=(1-rho)*sqrt(p);
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
eta=tau*lambda/(a/b^2*lambda+K);%imperfect CSI
%
if CSI_flag%perfect CSI
    tau=0;
    eta=1;
end
for i=1:length(M)
Hl=GHl(M(i),K);
Hh=sqrt(eta)*sqrt(1/2)*(randn(M(i),K)+1i*randn(M(i),K));
H=Hl*Ol+Hh*Oh;
Hf=(H'*H)^-1;
R=eta*Oh^2+1/M(i)*Ol*(Hl'*Hl)*Ol;
Rf=R^-1;
%analysis
Rsumzf1=0;
for t=1:K
gammazf1=(1-rho)*(K11+1)*p/((1-rho)*delta^2*(K11+1)*p+((1+delta^2)*(1-eta)*K*p+rho*(1+delta^2)*(eta+K11)*K*p+K11+1+(1+delta^2)*(K11+1)*p*sum(sbrli))*Rf(t,t)/(M(i)-K));
Rsumzf1=Rsumzf1+zeta*(1-tau/N)*log2(1+gammazf1);
end
Rszf1(i)=Rsumzf1;
%simulation
Rsumzf2=0;
for m=1:K
gammazf2=(1-rho)*(K11+1)*p/((1-rho)*delta^2*(K11+1)*p+((1+delta^2)*(1-eta)*K*p+rho*(1+delta^2)*(eta+K11)*K*p+K11+1+(1+delta^2)*(K11+1)*p*sum(sbrli))*Hf(m,m));
Rsumzf2=Rsumzf2+zeta*(1-tau/N)*log2(1+gammazf2);
end
Rszf2(i)=Rsumzf2;
end



