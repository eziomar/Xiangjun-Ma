function [Rs1,Rs2]=MRTa(zeta,tau,N,K,M,K11,K22,rho,delta,beta_ii,beta_il,beta_li,flag,alpha)%M
nbrBSs=7;%��վ��Ŀ
Rs1=zeros(1,length(M));
Rs2=zeros(1,length(M));
p0=10;
p=p0*M.^-alpha;
sbrli=0;%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end

for i=1:length(M)
Hl=GHl(M(i),K);
%
a=(1-rho)*((rho+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p(i)+1);
b=(1-rho)*sqrt(p(i));
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
eta=tau*lambda/(a/b^2*lambda+K);%imperfect CSI
%
if flag%perfect CSI
    tau=0;
    eta=1;
end
Rsum1=0;

for t=1:K
sum1=0;
u=1:K;
u(find(u==t))=[];
for n=u
    sum1=sum1+beta_ii(t,1)/beta_ii(n,1)*norm(dot(Hl(:,t),Hl(:,n)))^2;
end
%
sbrilt=0;
for q=2:nbrBSs
    sbrilt=sbrilt+beta_il(t,q)./beta_ii(:,q);
end
de_6=M(i)*(K11+1)*((delta^2*(1-rho)+1)*p(i)*(sum(beta_il(t,1)./beta_ii(:,1))+sum(sbrilt))+1)+2*K11*(1-rho)*(delta^2*M(i)-1)*M(i)*p(i);
de_7=M(i)*K11*(K11+1)*((delta^2*(1-rho)+1)*p(i)*sum(sbrilt)+rho*p(i)*sum(beta_il(t,1)./beta_ii(:,1))+1)+(1-rho)*K11*p(i)*((1+delta^2)*K11*sum1+(1+delta^2)*M(i)*sum(beta_il(t,1)./beta_ii(:,1))+delta^2*K11*M(i)^2);
afm=M(i)*(delta^2*M(i)-1)*(1-rho)*p(i)*eta^2+de_6*eta+de_7;
afz=(1-rho)*M(i)*p(i)*((M(i)+1)*eta^2+2*(M(i)+1)*K11*eta+M(i)*K11^2);

gamma1=afz/afm;
Rsum1=Rsum1+zeta*(1-tau/N)*log2(1+gamma1);
end
Rs1(i)=Rsum1;
end