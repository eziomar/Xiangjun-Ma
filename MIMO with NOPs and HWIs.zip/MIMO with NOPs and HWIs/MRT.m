function [Rs1,Rs2]=MRT(zeta,tau,N,K,M,K11,K22,rho,delta,beta_ii,beta_il,beta_li,CSI_flag)%M
nbrBSs=7;%��վ��Ŀ
Rs1=zeros(1,length(M));
Rs2=zeros(1,length(M));
B=diag(beta_ii(:,1).^-1);
p=10;
sbrli=0;%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end
%
a=(1-rho)*((rho+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p+1);
b=(1-rho)*sqrt(p);
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
eta=tau*lambda/(a/b^2*lambda+K);%imperfect CSI
%
if CSI_flag%perfect CSI
    tau=0;
    eta=1;
end
for i=1:length(M)
Hl=GHl(M(i),K);
Hh=sqrt(eta)*sqrt(1/2)*(randn(M(i),K)+1i*randn(M(i),K));

HS=Hh*B*Hh'+sqrt(K11)*Hh*B*Hl'+sqrt(K11)*Hl*B*Hh'+K11*Hl*B*Hl';

%
%analysis
Rsum1=0;

for t=1:K
sum1=0;
u=1:K;
u(find(u==t))=[];
for n=u
    sum1=sum1+beta_ii(t,1)/beta_ii(n,1)*norm(dot(Hl(:,t),Hl(:,n)))^2;
end
%
sbrilt=0;
for q=2:nbrBSs
    sbrilt=sbrilt+beta_il(t,q)./beta_ii(:,q);
end
de_6=M(i)*(K11+1)*((delta^2*(1-rho)+1)*p*(sum(beta_il(t,1)./beta_ii(:,1))+sum(sbrilt))+1)+2*K11*((1-rho)*(delta^2*M(i)-1)+rho)*M(i)*p;
de_7=M(i)*K11*(K11+1)*((delta^2*(1-rho)+1)*p*sum(sbrilt)+rho*p*sum(beta_il(t,1)./beta_ii(:,1))+1)+(1-rho)*K11*p*((1+delta^2)*K11*sum1+(1+delta^2)*M(i)*sum(beta_il(t,1)./beta_ii(:,1))+delta^2*K11*M(i)^2);
afm=M(i)*((delta^2*M(i)-1)*(1-rho)+rho)*p*eta^2+de_6*eta+de_7;
afz=(1-rho)*M(i)*p*((M(i)+1)*eta^2+2*(M(i)+1)*K11*eta+M(i)*K11^2);
%afm1=M(i)*(K11+eta)*(K11+1)*((delta^2*(1-rho)+1)*p*(K*beta_21/beta_22)+rho*p*K+1);
%afm2=(1+delta^2)*(1-rho)*p*(K11^2*sum1+(K-1)*(2*K11*M(i)*eta+M(i)*eta^2));
%afm3=(1+delta^2)*(1-rho)*(1-eta)*(K11+eta)*M(i)*p*K;
%afm4=delta^2*(1-rho)*p*(K11^2*M(i)^2+2*K11*M(i)*(M(i)+1)*eta+M(i)*(M(i)+1)*eta^2);
%gamma1=afz/(afm1+afm2+afm3+afm4);
gamma1=afz/afm;
Rsum1=Rsum1+zeta*(1-tau/N)*log2(1+gamma1);
end
Rs1(i)=Rsum1;
%simulation
Rsum2=0;
for m=1:K
sum2=0;
v= 1:K;
v(find(v==m))=[];
for j=v
    sum2=sum2+beta_ii(m,1)/beta_ii(j,1)*norm(dot(sqrt(K11)*Hl(:,m)+Hh(:,m),sqrt(K11)*Hl(:,j)+Hh(:,j)))^2;
end
sumn=0;
for w=1:K
    sumn=sumn+beta_ii(m,1)./beta_ii(w,1)*norm(sqrt(K11)*Hl(:,w)+Hh(:,w))^2;
end
sbrilm=0;
for s=2:nbrBSs
    sbrilm=sbrilm+beta_il(m,s)./beta_ii(:,s);
end
sfz=(1-rho)*p*norm(sqrt(K11)*Hl(:,m)+Hh(:,m))^4;
sfm1=M(i)*(K11+eta)*(K11+1)*((delta^2*(1-rho)+1)*p*sum(sbrilm)+1);
sfm2=delta^2*(1-rho)*p*norm(sqrt(K11)*Hl(:,m)+Hh(:,m))^4;
sfm3=(1+delta^2)*(1-rho)*p*sum2;
sfm4=(1+delta^2)*(1-rho)*(1-eta)*p*sumn;
sfa=beta_ii(m,1)*(1-eta)*rho*p*trace(HS)+rho*beta_ii(m,1)*p*(sqrt(K11)*Hl(:,m)+Hh(:,m))'*diag(diag(HS))*(sqrt(K11)*Hl(:,m)+Hh(:,m));
gamma2=sfz/(sfm1+sfm2+sfm3+sfm4+sfa);
Rsum2=Rsum2+zeta*(1-tau/N)*log2(1+gamma2);
end
Rs2(i)=Rsum2;
end