function [Rszf1,Rszf2]=ZFa(zeta,tau,N,K,M,K11,K22,rho,delta,beta_ii,beta_li,flag,alpha)%M
Ol=sqrt(K11/(K11+1))*eye(K);Oh=sqrt(1/(K11+1))*eye(K);
nbrBSs=7;%��վ��Ŀ
Rszf1=zeros(1,length(M));
Rszf2=zeros(1,length(M));
p0=10;
p=p0*M.^-alpha;
sbrli=0;%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end
for i=1:length(M)
Hl=GHl(M(i),K);
%
a=(1-rho)*((rho+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p(i)+1);
b=(1-rho)*sqrt(p(i));
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
eta=tau*lambda/(a/b^2*lambda+K);%imperfect CSI
% 
if flag%perfect CSI
    tau=0;
    eta=1;
end
R=eta*Oh^2+1/M(i)*Ol*(Hl'*Hl)*Ol;
Rf=R^-1;

Rsumzf1=0;
for t=1:K
gammazf1=(1-rho)*(K11+1)*p(i)/((1-rho)*delta^2*(K11+1)*p(i)+((1+delta^2)*(1-eta)*K*p(i)+rho*(1+delta^2)*(eta+K11)*K*p(i)+K11+1+(1+delta^2)*(K11+1)*p(i)*sum(sbrli))*Rf(t,t)/(M(i)-K));
Rsumzf1=Rsumzf1+zeta*(1-tau/N)*log2(1+gammazf1);
end
Rszf1(i)=Rsumzf1;
end



