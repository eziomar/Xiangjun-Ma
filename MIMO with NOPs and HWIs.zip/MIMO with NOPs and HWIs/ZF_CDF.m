function [Rszf]=ZF_CDF(zeta,tau,N,K,M,K11,K22,rho,delta,beta_ii,beta_li)%M
Ol=sqrt(K11/(K11+1))*eye(K);Oh=sqrt(1/(K11+1))*eye(K);
nbrBSs=7;%��վ��Ŀ
Rszf=zeros(K,1);%K���û��ֱ������
p=10;
sbrli=0;%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end
%
a=(1-rho)*((rho+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p+1);
b=(1-rho)*sqrt(p);
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
eta=tau*lambda/(a/b^2*lambda+K);%imperfect CSI
%
Hlcell=load('Hl.mat','Hl');
Hl=Hlcell.Hl;
Hh=sqrt(eta)*sqrt(1/2)*(randn(M,K)+1i*randn(M,K));
H=Hl*Ol+Hh*Oh;
Hf=(H'*H)^-1;
%simulation
for m=1:K
gammazf2=(1-rho)*(K11+1)*p/((1-rho)*delta^2*(K11+1)*p+((1+delta^2)*(1-eta)*K*p+rho*(1+delta^2)*(eta+K11)*K*p+K11+1+(1+delta^2)*(K11+1)*p*sum(sbrli))*Hf(m,m));
Rszf(m)=zeta*(1-tau/N)*log2(1+gammazf2);
end



