%conclusion:S2��Mͬ��
clear all
clc
M=10000;
S2=M;
for k=1:M-1
    S2=S2+2*(M-k)*besselj(0,k*pi);
end
S2