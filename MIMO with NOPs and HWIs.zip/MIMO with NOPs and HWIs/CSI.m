clear all
clc
zeta=0.5;tau=100;N=1800;K=120;
rho=0:0.1:1;
delta=0.1;K22=10^0.3;K11=10^0.3;
nbrBSs=7;%��վ��Ŀ
p=10;
[beta_ii,beta_il,beta_li]=pathlossgenerate(K);
sbrli=0;%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end
%
a=(1-rho).*((rho+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p+1);
b=(1-rho)*sqrt(p);
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
eta=tau*lambda./(a./(b.^2)*lambda+K);%imperfect CSI
plot(rho,eta)