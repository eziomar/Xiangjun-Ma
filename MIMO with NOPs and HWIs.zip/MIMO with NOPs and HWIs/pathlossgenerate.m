function [beta_ii,beta_il,beta_li]=pathlossgenerate(K)%K:ÿ��С�����û���
%shadow fading
sigmash=4;%dB
%Pathloss exponent
kappa = 3.7;
%Percentage of the radius inside the cell where no UEs are allowed
forbiddenRegion = 0.14;

%Define intersite distance in a normalized scale
intersiteDistance = 2;
intersiteDistanceHalf = intersiteDistance/2;

dmax = intersiteDistanceHalf; %Normalized cell radius
dmin = dmax * forbiddenRegion; %Normalized shortest distance from a BS
    %the number of BSs
    nbrBSs = 7;
    %Vector with BS positions
    BSpositions = zeros(nbrBSs,1);
    BSpositions(2)=sqrt(3)*exp(1i*pi*1/6);
    BSpositions(3)=sqrt(3)*exp(1i*pi*3/6);
    BSpositions(4)=sqrt(3)*exp(1i*pi*5/6);
    BSpositions(5)=sqrt(3)*exp(1i*pi*7/6);
    BSpositions(6)=sqrt(3)*exp(1i*pi*9/6);
    BSpositions(7)=sqrt(3)*exp(1i*pi*11/6);


    
    %Prepare to put out UEs in the cells
    UEpositions = zeros(K,nbrBSs);
    
    %Initiate matrices of mathloss
    beta_ii=zeros(K,nbrBSs);
    beta_il=zeros(K,nbrBSs);
    beta_li=zeros(K,nbrBSs);
  
    %Go through all the cells
    for i = 1:nbrBSs
        
        %Generate UE locations randomly with uniform distribution inside the cells
        nbrToGenerate = K; %Number of UE locations left to generate
        notFinished = true(K,1); %Indices of the UE locations that are left to generate
        
        
        %Iterate the generation of UE locations until all of them are inside a
        %hexagonal cell
        while nbrToGenerate>0
            
            %Generate new UE locations uniformly at random in a circle of radius dmax
            UEpositions(notFinished,i) = sqrt( rand(nbrToGenerate,1)*(dmax^2-dmin^2)+ dmin^2 ) .* exp(1i*2*pi*rand(nbrToGenerate,1));
            
            %Check which UEs that are inside a hexagonal and declare as finished
            finished = checkHexagonal(UEpositions(:,i)',dmax);
            
            %Update which UEs that are left to generate
            notFinished = (finished==false);
            
            %Update how many UEs that are left to generate
            nbrToGenerate = sum(notFinished);
            
        end
        %Finalize UE locations by translating them around the serving BS
        UEpositions(:,i) = UEpositions(:,i) + BSpositions(i);
        
        %Compute beta_ii
        beta_ii(:,i)=abs(UEpositions(:,i) - BSpositions(i)).^(-kappa);
        %Focus on interference caused to the first BS (in the center)
        l = 1;
        %Compute beta_il(downlink)
        beta_il(:,i)=abs(UEpositions(:,l) - BSpositions(i)).^(-kappa);
        %Comput beta_li(uplink)
        beta_li(:,i)=abs(UEpositions(:,i) - BSpositions(l)).^(-kappa);
        %������Ӱ˥��
        if i==1
            rvsh=10.^(10^(sigmash/10-1)*randn(K,1));
            beta_ii(:,i)=beta_ii(:,i).*rvsh;
            beta_il(:,i)=beta_ii(:,i);
            beta_li(:,i)=beta_ii(:,i);
        elseif i~=1
            beta_ii(:,i)=beta_ii(:,i).*10.^(10^(sigmash/10-1)*randn(K,1));
            beta_il(:,i)=beta_il(:,i).*10.^(10^(sigmash/10-1)*randn(K,1));
            beta_li(:,i)=beta_li(:,i).*10.^(10^(sigmash/10-1)*randn(K,1));
        end
    end
    
    %scatter(real(UEpositions(:,i)- BSpositions(i)),imag(UEpositions(:,i)- BSpositions(i)))