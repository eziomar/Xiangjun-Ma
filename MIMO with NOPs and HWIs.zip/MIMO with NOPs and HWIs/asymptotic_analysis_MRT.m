clear all
clc
p0=10;
zeta=0.5;tau=100;N=1800;K=120;
alpha=[0.5,1];K11=[0,10^0.9];
M_mrt=[10^3,0.3*10^4,10^4,0.3*10^5,10^5,0.3*10^6,10^6,0.3*10^7,10^7];
rho=0.1175;delta=0.1;K22=2;
[beta_ii,beta_il,beta_li]=pathlossgenerate(K);
%1:perfect;0:imperfect
%MRT
    %imperfect
    [R1a,R2a]=MRTa(zeta,tau,N,K,M_mrt,K11(1),K22,rho,delta,beta_ii,beta_il,beta_li,0,alpha(1));
    [R1b,R2b]=MRTa(zeta,tau,N,K,M_mrt,K11(2),K22,rho,delta,beta_ii,beta_il,beta_li,0,alpha(2));
    %perfect
    [Rp1a,Rp2a]=MRTa(zeta,tau,N,K,M_mrt,K11(1),K22,rho,delta,beta_ii,beta_il,beta_li,1,alpha(2));
    [Rp1b,Rp2b]=MRTa(zeta,tau,N,K,M_mrt,K11(2),K22,rho,delta,beta_ii,beta_il,beta_li,1,alpha(2));
%�������ʷ���
%MRT
    %imperfect
    p1=semilogx(M_mrt,R1a,'o--r','LineWidth',1);
    hold on
    p2=semilogx(M_mrt,R1b,'*--b','LineWidth',1);
    hold on
    %perfect
    semilogx(M_mrt,Rp1a,'o--r','LineWidth',1);
    hold on
    semilogx(M_mrt,Rp1b,'*--b','LineWidth',1);
    hold on
%������������
R_mrt_imp_nLOS=zeta*(1-tau/N)*log2(1+(1-rho)^2*tau*p0^2/(delta^2*(1-rho)^2*tau*p0^2+1));
R_mrt_imp_LOS=zeta*(1-tau/N)*log2(1+(1-rho)*K11(2)*p0/(delta^2*(1-rho)*K11(2)*p0+K11(2)+1));
R_mrt_p=zeta*log2(1+(1-rho)*p0/(delta^2*(1-rho)*p0+1));

p5=semilogx(M_mrt,K*R_mrt_imp_nLOS*ones(size(M_mrt)),'r:','LineWidth',1);
hold on
p6=semilogx(M_mrt,K*R_mrt_imp_LOS*ones(size(M_mrt)),'k:','LineWidth',1);
hold on
p7=semilogx(M_mrt,K*R_mrt_p*ones(size(M_mrt)),'b:','LineWidth',1);
%ͼ��
legend([p1 p2 p5 p6 p7],{'MRT (K_{ll}=-\inftydB)','MRT (K_{ll}=9dB)','Asymptotic limit a','Asymptotic limit b','Asymptotic limit c'})
xlim([M_mrt(1) M_mrt(end)])
xlabel('Number of BS Antennas (\it{M})')
ylabel('Downlink Sum Rate \it{R_{d,l}^{mrt}} (\it{R_{d,l}^{P,mrt}})')
