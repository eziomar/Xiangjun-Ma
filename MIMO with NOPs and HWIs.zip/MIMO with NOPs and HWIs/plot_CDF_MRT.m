clear all%��Ҫ���GHl_for_CDFһ��
clc
mont=120;
zeta=0.5;tau=100;N=1800;K=120;M=600;K22=10^0.3;K11=0;
rho_ad=[0,0.1175];rho_da=[0,0.3634];delta=[0,0.55];
Rs1_tot=zeros(K,mont);
Rs2_tot=zeros(K,mont);
Rs3_tot=zeros(K,mont);
Rs4_tot=zeros(K,mont);
Rs5_tot=zeros(K,mont);
Rs6_tot=zeros(K,mont);

[beta_ii,beta_il,beta_li]=pathlossgenerate(K);%ȷ���Ĵ�߶�˥��
for n=1:mont
Rs1=MRT_CDF(zeta,tau,N,K,M,K11,K22,rho_ad(1),rho_da(1),delta(1),beta_ii,beta_il,beta_li);
Rs2=MRT_CDF(zeta,tau,N,K,M,K11,K22,rho_ad(1),rho_da(1),delta(2),beta_ii,beta_il,beta_li);
Rs3=MRT_CDF(zeta,tau,N,K,M,K11,K22,rho_ad(1),rho_da(2),delta(1),beta_ii,beta_il,beta_li);
Rs4=MRT_CDF(zeta,tau,N,K,M,K11,K22,rho_ad(2),rho_da(1),delta(1),beta_ii,beta_il,beta_li);
Rs5=MRT_CDF(zeta,tau,N,K,M,K11,K22,rho_ad(2),rho_da(1),delta(2),beta_ii,beta_il,beta_li);
Rs6=MRT_CDF(zeta,tau,N,K,M,K11,K22,rho_ad(2),rho_da(2),delta(1),beta_ii,beta_il,beta_li);
Rs1_tot(:,n)=real(Rs1);
Rs2_tot(:,n)=real(Rs2);
Rs3_tot(:,n)=real(Rs3);
Rs4_tot(:,n)=real(Rs4);
Rs5_tot(:,n)=real(Rs5);
Rs6_tot(:,n)=real(Rs6);
end
hold on;box on;
p1=plot([0;sort(Rs1_tot(:));1.6],[0,linspace(0,1,K*mont),1],'--r','LineWidth',2);
p2=plot([0;sort(Rs2_tot(:));1.6],[0,linspace(0,1,K*mont),1],'--k','LineWidth',2);
p3=plot([0;sort(Rs3_tot(:));1.6],[0,linspace(0,1,K*mont),1],'--b','LineWidth',2);
p4=plot([0;sort(Rs4_tot(:));1.6],[0,linspace(0,1,K*mont),1],':r','LineWidth',2);
p5=plot([0;sort(Rs5_tot(:));1.6],[0,linspace(0,1,K*mont),1],':k','LineWidth',2);
p6=plot([0;sort(Rs6_tot(:));1.6],[0,linspace(0,1,K*mont),1],':b','LineWidth',2);
xlabel('Spectral Efficiency per UE');
ylabel('Cumulative Distribution Function(CDF)');
legend([p1,p2,p3,p4,p5,p6],{'\rho_{ad}=0,\rho_{da}=0,\delta_{rx}=0','\rho_{ad}=0,\rho_{da}=0,\delta_{rx}=0.55','\rho_{ad}=0,\rho_{da}=0.3634,\delta_{rx}=0','\rho_{ad}=0.1175,\rho_{da}=0,\delta_{rx}=0','\rho_{ad}=0.1175,\rho_{da}=0,\delta_{rx}=0.55','\rho_{ad}=0.1175,\rho_{da}=0.3634,\delta_{rx}=0'})
xlim([0 1.2])
