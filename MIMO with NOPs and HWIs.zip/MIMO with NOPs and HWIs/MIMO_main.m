clear all
clc
zeta=0.5;tau=100;N=1800;K=120;
M_mrc=[10 30 60 120 280 500 1024 2048 3072];%or M_mrt
M_zf=[125 200 280 500 750 1024 2048 3072];
rho=0.1175;delta=0.1;K22=10^0.3;
%generate largescale fading, beta_il(downlink), beta_li(uplink)
[beta_ii,beta_il,beta_li]=pathlossgenerate(K);
CSI_flag=[0,1];%0:imperfect; 1:perfect
for K11=[0 10^0.3 10^0.6 10^0.9]%-\inftydB,3dB,6dB,9dB    
    %[Rs1,Rs2]=MRC(zeta,tau,N,K,M_mrc,K11,K22,rho,delta,beta_ii,beta_li,CSI_flag(1));%1:perfect;0:imperfect
    [Rs1,Rs2]=MRT(zeta,tau,N,K,M_mrc,K11,K22,rho,delta,beta_ii,beta_il,beta_li,CSI_flag(1));%1:perfect;0:imperfect
    p1=semilogx(M_mrc,Rs1,'*--r','LineWidth',1);%MRC
    hold on
    p2=semilogx(M_mrc,Rs2,'+--b','LineWidth',1);
    hold on
end
%for Kllzf=[0 10^0.9]
   %[Rszf1,Rszf2]=ZF(zeta,tau,N,K,M_zf,Kllzf,K22,rho,delta,beta_ii,beta_li,1);%1:perfect;0:imperfect
   %p3=semilogx(M_zf,Rszf1,'x--k','LineWidth',1);%ZF
   %hold on
   %p4=semilogx(M_zf,Rszf2,'s--g','LineWidth',1);
   %hold on
%end
%legend([p1 p2 p3 p4],{'MRC Approximation','MRC Simulation','ZF Lower-bound','ZF Simulation'})
legend([p1 p2],{'MRT Approximation','MRT Simulation'})
xlim([M_mrc(1) M_mrc(end)])
xlabel('Number of BS Antennas (\it{M})')
%ylabel('Uplink Sum Rate R_{u,l}^{mrc/zf}')
%ylabel('Uplink Sum Rate R_{u,l}^{P,mrc/zf}')
ylabel('Downlink Sum Rate R_{d,l}^{mrt}')
%ylabel('Downlink Sum Rate R_{d,l}^{P,mrt}')
text(20,100,'K_{ll}=-\inftydB,9dB')
text(20,100,'K_{ll}=-\inftydB,3dB,6dB,9dB')
%text(20,100,'K_{ll}=-\inftydB')



