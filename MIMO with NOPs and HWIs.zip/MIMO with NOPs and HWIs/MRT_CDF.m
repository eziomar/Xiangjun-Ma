function [Rs]=MRT_CDF(zeta,tau,N,K,M,K11,K22,rho_ad,rho_da,delta,beta_ii,beta_il,beta_li)%M
nbrBSs=7;%��վ��Ŀ
Rs=zeros(K,1);
p=10;
sbrli=zeros(K,1);%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end
%
a=(1-rho_ad)*((rho_ad+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p+1);
b=(1-rho_ad)*sqrt(p);
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
eta=tau*lambda/(a/b^2*lambda+K);%imperfect CSI
%
Hlcell=load('Hl.mat','Hl');
Hl=Hlcell.Hl;
Hh=sqrt(eta)*sqrt(1/2)*(randn(M,K)+1i*randn(M,K));
%simulation
for m=1:K
sum2=0;
v= 1:K;
v(find(v==m))=[];
for j=v
    sum2=sum2+beta_ii(m,1)/beta_ii(j,1)*norm(dot(sqrt(K11)*Hl(:,m)+Hh(:,m),sqrt(K11)*Hl(:,j)+Hh(:,j)))^2;
end
sumn=0;
for w=1:K
    sumn=sumn+beta_ii(m,1)./beta_ii(w,1)*norm(sqrt(K11)*Hl(:,w)+Hh(:,w))^2;
end
sbrilm=0;
for s=2:nbrBSs
    sbrilm=sbrilm+beta_il(m,s)./beta_ii(:,s);
end
sfz=(1-rho_da)*p*norm(sqrt(K11)*Hl(:,m)+Hh(:,m))^4;
sfm1=M*(K11+eta)*(K11+1)*((delta^2*(1-rho_da)+1)*p*sum(sbrilm)+rho_da*p/(M*(K11+1))*(M*(1-eta)+norm(sqrt(K11)*Hl(:,m)+Hh(:,m))^2)*sum(beta_il(m,1)./beta_ii(:,1))+1);
sfm2=(1+delta^2)*(1-rho_da)*p*sum2;
sfm3=(1+delta^2)*(1-rho_da)*(1-eta)*p*sumn;
sfm4=delta^2*(1-rho_da)*p*norm(sqrt(K11)*Hl(:,m)+Hh(:,m))^4;
gamma2=sfz/(sfm1+sfm2+sfm3+sfm4);
Rs(m)=zeta*(1-tau/N)*log2(1+gamma2);
end