clear all
clc;
qbits=[1,2,3,4,5,6];%��������6��������
rho=[0.3634,0.1175,0.03454,0.009497,0.002499,0];
[S1a,S2a]=nonorthogonal(rho,0.1,120);%�������(S1:׼ȷֵ, S2:����ֵ);�������(rho,delta,�û���)
[S1b,S2b]=nonorthogonal(rho,0.5,120);
[S1c,S2c]=nonorthogonal(rho,0.1,240);
[S1d,S2d]=nonorthogonal(rho,0.5,240);
plot(-1,-1,'*--r',-1,-1,'+--b',-1,-1,'x--k',-1,-1,'s--g')
hold on
plot(qbits,S1a,'*--r',qbits,S2a,'+--b',qbits,S1b,'*--r',qbits,S2b,'+--b',qbits,S1c,'x--k',qbits,S2c,'s--g',qbits,S1d,'x--k',qbits,S2d,'s--g','LineWidth',1);
xlim([qbits(1) qbits(end)])
ylim([0.5 1])
%legend('Exact (\delta_{tx}=0.1)','Approximation (\delta_{tx}=0.1)','Exact (\delta_{tx}=0.5)','Approximation (\delta_{tx}=0.5)','Accurate (\delta_{tx}=0.1)','Approximation (\delta_{tx}=0.1)','Accurate (\delta_{tx}=0.5)','Approximation (\delta_{tx}=0.5)')
legend('Exact (K=120)','Approximation (K=120)','Exact (K=240)','Approximation (K=240)')
xlabel('Q-bit b_{ad}')
ylabel('Variance of CE Error \sigma_l^2')
text(2,0.7,'\delta_{tx}=0.1')
text(2,0.7,'\delta_{tx}=0.5')