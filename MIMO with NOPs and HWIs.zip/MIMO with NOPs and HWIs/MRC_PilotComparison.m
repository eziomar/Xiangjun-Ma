function [Rs1,Rs2]=MRC_PilotComparison(zeta,tau,N,K,M,K11,rho,delta)%M

Rs1=zeros(1,length(M));
Rs2=zeros(1,length(M));
p=10;

%
eta=zeros(1,2);
eta(1)=tau(1)/(((rho+delta^2)*K*(K11+1)+1)/((1-rho)*p)+K);%Non-OP
eta(2)=tau(2)/(((rho+delta^2)*K*(K11+1)+1)/((1-rho)*p)+tau(2));%OP

for i=1:length(M)
Hl=GHl(M(i),K);


Rsum1=0;
Rsum2=0;

for t=1:K
sum1=0;
u=1:K;
u(find(u==t))=[];
for n=u
    sum1=sum1+norm(dot(Hl(:,t),Hl(:,n)))^2;
end
%Non-OPs
gamma1=(1-rho)*((M(i)+1)*p*eta(1)^2+2*(M(i)+1)*K11*p*eta(1)+M(i)*K11^2*p)/(((M(i)*delta^2-1)*(1-rho)+rho*(1+delta^2))*p*eta(1)^2+(2*((M(i)+rho)*delta^2+2*rho-1)*K11*p+K11+1+(1+delta^2)*(K11+1)*p*K)*eta(1)+M(i)*(1-rho)*delta^2*K11^2*p+(1+delta^2)*(1+rho*K11)*K11*K*p+K11*(K11+1)+1/M(i)*(1-rho)*(1+delta^2)*K11^2*p*sum1);
%OPs
gamma2=(1-rho)*((M(i)+1)*p*eta(2)^2+2*(M(i)+1)*K11*p*eta(2)+M(i)*K11^2*p)/(((M(i)*delta^2-1)*(1-rho)+rho*(1+delta^2))*p*eta(2)^2+(2*((M(i)+rho)*delta^2+2*rho-1)*K11*p+K11+1+(1+delta^2)*(K11+1)*p*K)*eta(2)+M(i)*(1-rho)*delta^2*K11^2*p+(1+delta^2)*(1+rho*K11)*K11*K*p+K11*(K11+1)+1/M(i)*(1-rho)*(1+delta^2)*K11^2*p*sum1);
Rsum1=Rsum1+zeta*(1-tau(1)/N)*log2(1+gamma1);
Rsum2=Rsum2+zeta*(1-tau(2)/N)*log2(1+gamma2);
end
Rs1(i)=Rsum1;
Rs2(i)=Rsum2;
end
