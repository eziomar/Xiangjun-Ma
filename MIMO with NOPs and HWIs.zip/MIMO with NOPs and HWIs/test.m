clear all
clc

nbrBSs=7;
rho=0.03454;
S1=zeros(1,length(rho));S2=zeros(1,length(rho));
K11=10^0.3;K22=10^0.3;%3dB
delta=0.1;
tau=100;K=120;
v=zeros(1,K);
p=10;
[beta_ii,beta_il,beta_li]=pathlossgenerate(K);
sbrli=zeros(K,1);%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end
%������Ƶ����
w=exp(1)^(-1i*2*pi/K);
f=(1:tau)';
c=w.^f;
phi=zeros(tau,K);
for n=0:K-1
    phi(:,n+1)=c.^n;
end
%
a=(1-rho)*((rho+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p+1);
b=(1-rho)*sqrt(p);
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
for m=1:K
v(m)=phi(:,m)'*phi*(a/b^2*(Lambdallsquare+Lambdalisquare)^-1+phi'*phi)^-1*phi'*phi(:,m);
end
%

