function [S1,S2]=nonorthogonal(rho,delta,K)%������������Ƶ�Ĺ���ֵ�����ֵ
nbrBSs=7;
%rho=[0.002499,0.009497,0.03454,0.1175,0.3634];
S1=zeros(1,length(rho));S2=zeros(1,length(rho));
K11=10^0.3;K22=10^0.3;%3dB
%delta=0.1;
tau=100;%K=120;
p=10;
[beta_ii,beta_il,beta_li]=pathlossgenerate(K);
sbrli=zeros(K,1);%sum of beta ratio
for h=2:nbrBSs
sbrli=sbrli+beta_li(:,h)./beta_ii(:,h);%��߶�˥��ı�ֵ
end
%������Ƶ����
w=exp(1)^(-1i*2*pi/K);
f=(1:tau)';%f_1��f_{\tau}��ȡֵ
c=w.^f;
phi=zeros(tau,K);
for n=0:K-1
    phi(:,n+1)=c.^n;
end
%
for m=1:length(rho)
a=(1-rho(m))*((rho(m)+delta^2)*(K+sum(sbrli)*(K22+1)+K*K11)*p+1);
b=(1-rho(m))*sqrt(p);
Lambdalisquare=(K22+1)*diag(sbrli);
Lambdallsquare=diag(ones(1,K));
%
tr=trace(phi'*phi*(a/b^2*(Lambdallsquare+Lambdalisquare)^-1+phi'*phi)^-1);
sigma1=1-b^2*tau/a+b^2/a*tr;%׼ȷֵ
S1(m)=sigma1;
%
[V,D]=eig((Lambdallsquare+Lambdalisquare)^(-1));
lambda=mean(diag(D));
sigma2=1-tau*lambda/(a/b^2*lambda+K);%����ֵ
S2(m)=sigma2;
end
