function Hh=GHh(eta,M,K)
Hh=sqrt(eta)*sqrt(1/2)*(randn(M,K)+1i*randn(M,K));